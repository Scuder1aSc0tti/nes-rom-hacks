== INFO ==

This is a fan made remake of the bootleg ROM Hack "Teletubbies", which you could find in some multicarts like Super 500 in 1 on the PolyStation. Unlike the original version, it adds custom text (so you'll read Po instead of Mario and Lala instead of Luigi), adds upgraded graphics and also replaces all the enemeies (except the fighter fly).

This hack uses some graphics from other Mario Bros hacks, such as Pikachu Bros, Stoner Bros and Roge Brer, so shoutout to The Spoony Bard, el kadong and Inventor for the graphics!

== BACKSTORY ==

I've grown up with the original ROM Hack as a kid. It was included in the "Super 500-in-1" preloaded on the PolyStation I had at grandma's home. Everytime I return home from school I used to play a lot with the PolyStation, and the games I loved played on that thing were Olympics (aka Track and Field), Zippy Race and of course, Teletubbies. As a kid I thought it was a game about, well, Teletubbies, until I got a Wii with Super Smash Bros Brawl in it and saw the Mario Bros stage in the game and I realized that the Teletubbies game on the PolyStation was just a reskin of the original Mario Bros with Po and Lala instead of Mario and Luigi. 

15 years later, I've found a ROM of the original Super 500-in-1 multicart I had on the PolyStation (it was impossible to find that ROM anywhere), and to celebrate I decided to remake the Teletubbies ROM Hack with my own take.